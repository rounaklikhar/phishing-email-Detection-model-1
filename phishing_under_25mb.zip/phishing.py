import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix

# Sample dataset
data = {
    'email': [
        'Win money now click here',
        'Your account is hacked verify now',
        'Meeting scheduled tomorrow',
        'Project submission deadline',
        'Claim your free gift card',
        'Team lunch tomorrow'
    ],
    'label': [
        'Phishing',
        'Phishing',
        'Safe',
        'Safe',
        'Phishing',
        'Safe'
    ]
}

df = pd.DataFrame(data)

# Convert text into numbers
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(df['email'])

y = df['label']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# Train model
model = MultinomialNB()
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)

print("\nAccuracy:", accuracy)

# Confusion Matrix
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Test custom email
email = input("\nEnter Email Text: ")

email_data = vectorizer.transform([email])

prediction = model.predict(email_data)

print("\nPrediction:", prediction[0])